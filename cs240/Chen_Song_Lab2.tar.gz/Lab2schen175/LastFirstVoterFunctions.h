
using namespace std;
void New(string &last, string &first, int &age, int &strnum, string &strname,
	string &town, string &zip, float &donated);

void Update(string &last, string &first, int &age, int &strnum, string &strname,
	string &town, string &zip);

void View(string &last, string &first, int &age, int &strnum, string &strname,
	string &town, string &zip, float &donated);

void Donate(float &donated);

void Report(string &last, float &donated);
